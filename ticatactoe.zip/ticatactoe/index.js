const restartButton = document.querySelector('.restart button');
restartButton.addEventListener('click', restartGame)

let currentTurn = 1; /*0 for O, 1 for X (X starts)*/
let gridElements = [];
let winner = -1; /*-2 for draw -1 for none, 0 for O, 1 for X*/

function Initialize() {
    for(let i = 1; i <= 9; i++) {
        gridElements[i] = document.getElementById(""+i)
        gridElements[i].addEventListener("click", clickCell);
    }


}


// Handles clicking a grid cell
function clickCell(){
    if(winner === -1) {
        if (this.textContent === "") {
            this.textContent = currentTurn === 0 ? "O" : "X"; // Set "O" or "X"
            currentTurn = 1 - currentTurn;
            updateSubtitle();
        }
        checkForWin();
        checkForDraw();
    }
    if(winner !== -1) {
        handleWin();
    }
}
function checkForWin(){
    const cellsArray = document.querySelectorAll(".board div");
    const winningCombos = [
        [0, 1, 2], // Top row
        [3, 4, 5], // Middle row
        [6, 7, 8], // Bottom row
        [0, 3, 6], // Left column
        [1, 4, 7], // Middle column
        [2, 5, 8], // Right column
        [0, 4, 8], // Diagonal from top-left
        [2, 4, 6], // Diagonal from top-right
    ];

    for (const [a, b, c] of winningCombos) {
        if (
            cellsArray[a].textContent &&
            cellsArray[a].textContent === cellsArray[b].textContent &&
            cellsArray[a].textContent === cellsArray[c].textContent
        ) {
            winner = cellsArray[a].textContent === "X" ? 1 : 0; // 1 for X, 0 for O
            return;
        }
    }
}

function checkForDraw(){
    let cellsArray = document.querySelectorAll(".board div");
    let isDraw = true;
    for(let i = 0; i < 9; i++) {
        if(cellsArray[i].textContent === "X" || cellsArray[i].textContent === "O") {
            isDraw = true;
        }
        else {
            isDraw = false;
            return;
        }
    }
    winner = -2;
}

function handleWin() {
    const subtitle = document.querySelector('.turn h1')
    if(winner === 1) {
        subtitle.textContent = "X Won!";
        subtitle.style.color = "red"
    } else if(winner === 0) {
        subtitle.textContent = "O Won!";
        subtitle.style.color = "red"
    } else if(winner === -2) {
        subtitle.textContent = "Draw...";
        subtitle.style.color = "red"
    }
    const restartButton = document.querySelector('.restart');
    restartButton.style.display = "flex";
}


// lets player know whose turn it is
function updateSubtitle() {
    let subtitleElement =  document.querySelector(".turn h1");
    if(subtitleElement) {
        subtitleElement.textContent = `Current Turn: ${currentTurn === 0 ? "O" : "X"}`;
    }
}

function restartGame() {
    window.location.reload();
}


Initialize();